"The tank of tomorrow is here today."

Thank you for downloading! To install, open the folder with the vehicle(s) of your choosing (Chrysler K or Chrysler K GF) and drag the included .wotmod file to <Your WoT Directory\mods\<Game Version>

(Example: C:\Games\World_of_Tanks\mods\1.4.1.1)

Made by FastestClassic.